plugins { id("com.android.application") }

android {
    namespace = "com.vexo.messenger"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vexo.messenger"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
