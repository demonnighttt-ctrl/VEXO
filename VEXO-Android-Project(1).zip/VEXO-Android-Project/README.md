# VEXO Android preview

A minimal Android WebView wrapper for the VEXO interface preview. GitHub Actions builds an installable **debug APK** on each push to `main`/`master` or manually via Actions.

## Build artifact
Open the repository's **Actions** tab, select **Build VEXO APK**, open the successful run, then download **VEXO-debug-APK** under Artifacts.

## Current limitations
This is a UI preview only. It does not include a production backend, account registration, multi-user message delivery, real audio/video calling, push notifications, marketplace transactions, or payment processing. The debug APK is not a Play Store release and is not signed with a production release key.
